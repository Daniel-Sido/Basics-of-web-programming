const GRID_SIZE = 60;

module.exports = {
  initGame,
  gameLoop,
  getUpdatedVelocity,
	getPlayer1Points,
	getPlayer2Points,
}

// Инициализация карты в созданной комнате
function initGame() 
{
  const state = createGameState()
  randomFood(state);
  return state;
}

// Создание игровых объектов
function createGameState() 
{
  return {
    players: [
			{
      // Позиция головы
      pos: {
        x: 3,
        y: 10,
      },
      // Направление
      vel: {
        x: 1,
        y: 0,
      },
      // Составляющие змеи
      snake: [
        {x: 1, y: 10},
        {x: 2, y: 10},
        {x: 3, y: 10},
      ],
			// Очки 
			points: 0,
      move:1,
    }, 
		{
      // Позиция головы
      pos: {
        x: 18,
        y: 10,
      },
      // Направление
      vel: {
        x: 0,
        y: 1,
      },
      // Составляющие змеи
      snake: [
        {x: 20, y: 10},
        {x: 19, y: 10},
        {x: 18, y: 10},
      ],
			// Очки 
			points: 0,
      move:1,
    }],

    // Eда
    food: {},

    // Масштаб
    gridsize: GRID_SIZE,
  };
}

// Получение очков 1 игрока
function getPlayer1Points(state) 
{
	return state.players[0].points;
}

// Получение очков 2 игрока
function getPlayer2Points(state) 
{
	return state.players[1].points;
}

// Цикл игры
function gameLoop(state) 
{

  if (!state) 
	{
    return;
  }

  const playerOne = state.players[0];
  const playerTwo = state.players[1];

	// Движение
  playerOne.pos.x += playerOne.vel.x;
  playerOne.pos.y += playerOne.vel.y;

  playerTwo.pos.x += playerTwo.vel.x;
  playerTwo.pos.y += playerTwo.vel.y;

	// Выход за экран - проигрыш
  if (playerOne.pos.x < 0 || playerOne.pos.x >= GRID_SIZE || playerOne.pos.y < 0 || playerOne.pos.y >= (GRID_SIZE/2)) 
	{
    return 2;
  }

  if (playerTwo.pos.x < 0 || playerTwo.pos.x >= GRID_SIZE || playerTwo.pos.y < 0 || playerTwo.pos.y >= (GRID_SIZE/2)) {
    return 1;
  }

	// Поедание еды
  if (state.food.x === playerOne.pos.x && state.food.y === playerOne.pos.y) 
	{
    // Увеличиваем змею на 1 квадратик
    playerOne.snake.push({ ...playerOne.pos });
    playerOne.pos.x += playerOne.vel.x;
    playerOne.pos.y += playerOne.vel.y;
		playerOne.points++;

		// Генерируем новую еду в рандомной части карты
    randomFood(state);
  }

  if (state.food.x === playerTwo.pos.x && state.food.y === playerTwo.pos.y) 
	{
    
    playerTwo.snake.push({ ...playerTwo.pos });
    playerTwo.pos.x += playerTwo.vel.x;
    playerTwo.pos.y += playerTwo.vel.y;
		playerTwo.points++;
		
    randomFood(state);
  }

	// Столкновение с самим собой - проигрыш
  if (playerOne.vel.x || playerOne.vel.y) 
	{
		
    for (let cell of playerOne.snake) 
		{

      if (cell.x === playerOne.pos.x && cell.y === playerOne.pos.y) 
			{
        return 2;
      }

    }

		// Движение игрока - добавление ячейки и сдвиг
    playerOne.snake.push({ ...playerOne.pos });
    playerOne.snake.shift();
  }

		// Столкновение с самим собой - проигрыш
  if (playerTwo.vel.x || playerTwo.vel.y) 
	{

    for (let cell of playerTwo.snake) 
		{

      if (cell.x === playerTwo.pos.x && cell.y === playerTwo.pos.y) 
			{
        return 1;
      }

    }

		// Движение игрока - добавление ячейки и сдвиг
    playerTwo.snake.push({ ...playerTwo.pos });
    playerTwo.snake.shift();
  }

  // Cтолкновение второй змейки с какой-либо частью первой змейки - проигрышь второй змейки
  if (playerTwo.vel.x || playerTwo.vel.y) 
	{

    for (let cell of playerOne.snake) 
		{

      if (cell.x === playerTwo.pos.x && cell.y === playerTwo.pos.y) 
			{
        return 1;
      }

    }

  }

	// Cтолкновение первой змейки с какой-либо частью второй змейки - проигрышь первой змейки
  if (playerOne.vel.x || playerOne.vel.y) 
	{

    for (let cell of playerTwo.snake) 
		{

      if (cell.x === playerOne.pos.x && cell.y === playerOne.pos.y) 
			{
        return 2;
      }

    }

  }

	// Возврат лжи, так как игра не закончена
  return false;
}

// Генерация еды
function randomFood(state) 
{
	// Генерация новой еды с рандомными координатами на карте
  food = 
	{
    x: Math.floor(Math.random() * GRID_SIZE),
    y: Math.floor(Math.random() * GRID_SIZE/2), 
  }

	// Обязательная проверка на то, чтобы еда не сгенерировалась под первой змеей
  for (let cell of state.players[0].snake) 
	{

    if (cell.x === food.x && cell.y === food.y) 
		{
      return randomFood(state);
    }

  }

	// Обязательная проверка на то, чтобы еда не сгенерировалась под второй змеей
  for (let cell of state.players[1].snake) 
	{

    if (cell.x === food.x && cell.y === food.y) 
		{
      return randomFood(state);
    }

  }

  state.food = food;
}

// Смена направления движения в зависимости от нажатой клавиши
function getUpdatedVelocity(keyCode, vel) 
{
  switch (keyCode) 
	{
    case 37: { // Стрелка влево
			if(vel.x !== 1)
      	return { x: -1, y: 0 }; 
			else break;
    }
    case 38: { // Стрелка вниз
			if(vel.y !== 1)
     	 return { x: 0, y: -1 };
			else break;
    }
    case 39: { // Стрелка вправо
			if(vel.x !== -1)
      	return { x: 1, y: 0 };
			else break;
    }
    case 40: { // Стрелка вверх
			if(vel.y !== -1)
      	return { x: 0, y: 1 };
			else break;
    }
  }
	
	return undefined;
}
