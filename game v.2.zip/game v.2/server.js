// Импорт функций из файла game.js
const { initGame, gameLoop, getUpdatedVelocity, getPlayer1Points, getPlayer2Points } = require('./game');
const FRAME_RATE = 15;

let oneUpdateOneFrame;

const state = {};
const clientRooms = {};

const path = require('path');
const fs = require('fs');
const express = require('express');
const app = express();

let server = require('http').Server(app);

// Импортирование ввода и вывода сокетов
const io = require('socket.io')(server);

const jsonParser = express.json();
const urlencodedParser = express.urlencoded({ extended: false });

app.use(express.static(path.join(__dirname, '/public')))

app.get('/', (req, res) => {
  res.sendFile(`${__dirname}/public/select.html`);
});

app.post('/submit-form', jsonParser, function (req, res) {
  let comment = req.body;
  commentsString = JSON.stringify(comment, null, 2);
  fs.writeFileSync(`${__dirname}/public/database.json`, commentsString);
});

app.post('/login', urlencodedParser, function (req, res) {
  let login = req.body.authorization;

  if (login == "admin12345") res.send("1"); else res.send("0");

});

server.listen(8000, () => {
  console.log(`SERVER RUNNING ON PORT : 8000`);
});

// Прослушивание событий, поступающих от клиента
io.on('connection', client => {

  client.on('keydown', handleKeydown);
  client.on('newGame', handleNewGame);
  client.on('joinGame', handleJoinGame);

  // Событие присоединения к игре
  function handleJoinGame(roomName) {
    // Получение информации о пользователях
    const room = io.sockets.adapter.rooms.get(roomName);

    let allUsers;

    if (room) {
      allUsers = room;
    }

    let numClients = 0;

    // Получаем число клиентов в комнате
    if (allUsers) {
      numClients = room.size;
    }

    // Отправка клиенту инфомации, если комната с данным кодом не существует или в комнате уже находится 2 игрока 
    if (numClients === 0) {
      client.emit('unknownCode');
      return;
    } else if (numClients > 1) {
      client.emit('tooManyPlayers');
      return;
    }

    clientRooms[client.id] = roomName;

    // Вход (join) клиента в комнату под номером 2 и отправка клиенту этого номера
    client.join(roomName);
    client.number = 2;
    client.emit('init', 2);

    // Игра начинается только тогда, когда зашел второй игрок
    startGameInterval(roomName);
  }

  // Создание новой комнаты с уникальным названием
  function handleNewGame() {
    // Добавление новой комнаты с именем rootName (сгенерированный код длины 4) в глобальный объект
    let roomName = makeid(4);
    clientRooms[client.id] = roomName;

    // Отправка клиенту кода игры и добавление нового состояния (в котором еда всегда на новом месте) в глобальный объект
    client.emit('gameCode', roomName);
    state[roomName] = initGame();

    // Вход (join) клиента в комнату под номером 1 и отправка клиенту этого номера
    client.join(roomName);
    client.number = 1;
    client.emit('init', 1);
  }

  // Нажатие клавиш
  function handleKeydown(keyCode) {
    const roomName = clientRooms[client.id];

    if (!roomName) {
      return;
    }

    try {
      keyCode = parseInt(keyCode);
    }
    catch (e) {
      console.error(e);
      return;
    }

    if (state[roomName] !== null) {

      const vel = getUpdatedVelocity(keyCode, state[roomName].players[client.number - 1].vel);

      if (state[roomName].players[client.number - 1].move && vel) {
        state[roomName].players[client.number - 1].vel = vel;
        state[roomName].players[client.number - 1].move = 0;
      }

    }
  }

});

// Частота обновления
function startGameInterval(roomName) {
  const intervalId = setInterval(() => {
    // Получаем состояние комнаты
    const winner = gameLoop(state[roomName]);

    state[roomName].players[0].move = 1;
    state[roomName].players[1].move = 1;

    // Если победитель не определен, то игра все еще продолжается и передаем текущее состояние игры
    // иначе передаем GameOver
    if (!winner) {
      emitGameState(roomName, state[roomName])
    }
    else {
      // Отправка всем клиентам в данной комнате инфы об окончании игры
      emitGameOver(roomName, winner);

      // Сброс состояния комнаты
      state[roomName] = null;

      // Очистка интервала, чтобы больше не запускать игровой цикл, т. к. игра окончена
      clearInterval(intervalId);
    }

  }, 1000 / FRAME_RATE);
}

// Отправка всем клиентам в данной комнате инфы о текущем положение дел в игре
function emitGameState(room, gameState) {
  io.sockets.in(room)
    .emit('getPlayer1Points', getPlayer1Points(gameState));

  io.sockets.in(room)
    .emit('getPlayer2Points', getPlayer2Points(gameState));

  io.sockets.in(room)
    .emit('gameState', JSON.stringify(gameState));
}

// Отправка всем клиентам в данной комнате инфы об окончании игры
function emitGameOver(room, winner) {
  io.sockets.in(room)
    .emit('gameOver', JSON.stringify({ winner }));
}

// Генерируем код комнаты
function makeid(length) {
  var result = '';
  var characters = '0123456789';
  var charactersLength = characters.length;

  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }

  return result;
}
