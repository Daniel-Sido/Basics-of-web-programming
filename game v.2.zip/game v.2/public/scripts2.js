// Содержание комментария
class Feedback
{
    constructor(name, comment, data, agree)
    {
        this.Имя= name;
        this.Комментарий = comment;
        this.Дата = data;
    }
}

function BuildTable(data,place) 
{
    let table = place;
    let fields = Object.keys(data[0]);
    let like=fields.pop();
    data.forEach(function(object) 
		{
        let row = document.createElement("tr");

        fields.forEach(function(field) 
				{
            let cell = document.createElement("td");
            cell.textContent = object[field];

            if (typeof object[field] == "number") 
						{
                cell.style.textAlign = "center";
            }

            row.appendChild(cell);
        });

        table.querySelector('tbody').appendChild(row);
    });

    if(document.querySelector('#info-table-admin'))
    {
        let trs = table.querySelectorAll('tbody tr');

        for (let tr of trs)
        {
            let td = document.createElement('td');
            td.id="forLink";
            td.className="deleteRow";

            let links = document.querySelector('#forLink');
            links= document.createElement('a');
            links.className="buttonDB";
            links.textContent="X";

            td.appendChild(links);
            tr.appendChild(td);
        }

    }
		
    return table;
}

var comments=[];

if(document.querySelector('#itable'))
{
    let xml = new XMLHttpRequest();
    xml.open('GET','database.json');

    xml.onreadystatechange = function()
		{

        if(xml.readyState===4 && xml.status===200)
				{
            comments=JSON.parse(xml.responseText);
						let table;

						if(comments.length!= 0)
            table=BuildTable(comments,document.querySelector('#itable'));

						if(comments.length == 0)
						document.getElementById("info-table1").style.display = 'none';
						else
						document.getElementById("info-table1").style.display = '';
        }

    }

    xml.send();
}
else if(document.querySelector('#info-table-admin'))
{
   
    let xml = new XMLHttpRequest();
    xml.open('GET','database.json');
    
    xml.onreadystatechange = function()
		{

        if(xml.readyState===4 && xml.status===200)
				{
            comments=JSON.parse(xml.responseText);
						let tableAdmin;
						if(comments.length!= 0)
            tableAdmin=BuildTable(comments,document.querySelector('#info-table-admin'));
        }

    }

    xml.send();
}

let tableDel=document.querySelector('#info-table-admin');

if(tableDel != null)
{

		tableDel.addEventListener('click', function(evt)
		{

				if(evt.target.closest('.buttonDB')) 
				{
						let deleteRow=evt.target.closest('tr');
						deleteRow.remove();

						for(let str of comments)
						{
								
								if(deleteRow.childNodes[0].textContent==str.Имя && deleteRow.childNodes[1].textContent==str.Комментарий && deleteRow.childNodes[2].textContent==str.Дата)
								{
										let index = comments.indexOf(str);
										comments.splice(index, 1);
								}
								
						}

						let comString = JSON.stringify(comments);

						var xml = new XMLHttpRequest();
						xml.open('POST','submit-form');
						xml.setRequestHeader("Content-type","application/json");
						xml.send(comString);			
				}

		})

}

// Добавление комментария в файл и на страницу
function AddElements()
{
		document.getElementById("info-table1").style.display = '';
    let name= document.querySelector('#name').value;
    let comment= document.querySelector('#comm').value;

    if (comment == "" || name == "")
		{
			alert("Заполнены не все поля!");
			return;
		}

    var timeNow  = new Date();
    let time=timeNow.toLocaleString('ru-RU');
    comments.push (new Feedback(name, comment, time));

    let commentsString = JSON.stringify(comments);

    let xml = new XMLHttpRequest();
    xml.open('POST','submit-form');
    xml.setRequestHeader("Content-type","application/json");
    xml.send(commentsString);

    document.querySelector('#comm').value="";
    document.querySelector('#name').value="";
    
    var bdyRef = document.getElementById('itable').getElementsByTagName('tbody')[0];

    let tr = document.createElement('tr');
    let td = document.createElement('td');
    td.textContent=name;
    tr.appendChild(td);

    td = document.createElement('td');
    td.textContent=comment;
    tr.appendChild(td);

    td = document.createElement('td');
    td.textContent=time;

    tr.appendChild(td);
    bdyRef.appendChild(tr);
}

// Вход в аккаунт автора сайта, в случае удачи, в шапке появляются ссылки на управление комментариями и выход
function login()
{
    let login = document.querySelector('#login');
    let password = document.querySelector('#password');
    let authorization=login.value+password.value;
    authorization=encodeURIComponent(authorization);
    
    var xml = new XMLHttpRequest();
    xml.open('POST','login');
    xml.setRequestHeader("Content-type","application/x-www-form-urlencoded");

    xml.onreadystatechange = function()
		{

        if(xml.readyState===4 && xml.status===200)
				{

            if(xml.responseText=="1")
            {
                document.location.href = "#close";
								sessionStorage.setItem('flag', 1);
                hide1();
            }
						else
            {
                password.value="";
                alert("Неверный логин или пароль!");
            }

        }
    }

    xml.send('authorization=' + authorization);
}

// Флаг в sessionStorage, чтобы заменять ссылки Кабинет и выход на вход и наоборот
var changeRef=sessionStorage.getItem('flag');

if(changeRef == 1)
{
		hide1();
}

// Скрыть ссылку Вход, показать ссылки Управление и Выход
function hide1()
{
	const $node = document.querySelector('#node');
	const $liSecond= document.querySelector('#node li:nth-child(5)');

	$liSecond.parentNode.removeChild($liSecond);

	$node.insertAdjacentHTML('beforeend', '<li><a href="cabinet2.html" accesskey="3" title="">Управление</a></li>');
	$node.insertAdjacentHTML('beforeend', '<li><a onClick="hide2()" href="main2.html" accesskey="3" title="">Выход</a></li>');
}

// Скрыть ссылки Управление и Выход, показать ссылку Вход
function hide2()
{
	const $node = document.querySelector('#node');
	const $liSecond= document.querySelector('#node li:nth-child(5)');
	const $liThird = document.querySelector('#node li:nth-child(6)');

	$liSecond.parentNode.removeChild($liSecond);
	$liThird.parentNode.removeChild($liThird);

	$node.insertAdjacentHTML('beforeend', '<li><a href="#openModal">Вход</a></li>');
	
	sessionStorage.setItem('flag', 0);
}
