const SNAKE_COLOUR = '#FF1493';
const SNAKE_COLOUR2 = '#20B2AA';

const socket = io();

// Прослушивание событий, поступающих от сервера
socket.on('init', handleInit);
socket.on('gameState', handleGameState);
socket.on('gameOver', handleGameOver);
socket.on('gameCode', handleGameCode);
socket.on('unknownCode', handleUnknownCode);
socket.on('tooManyPlayers', handleTooManyPlayers);

socket.on('getPlayer1Points', getPlayer1Points);
socket.on('getPlayer2Points', getPlayer2Points);

const gameScreen = document.getElementById('gameScreen');

const initialScreen = document.getElementById('initialScreen');
const newGameBtn = document.getElementById('newGameButton');
const joinGameBtn = document.getElementById('joinGameButton');
const gameCodeInput = document.getElementById('gameCodeInput');
const gameCodeDisplay = document.getElementById('gameCodeDisplay');
const fire = document.getElementById('fire');

const numberOfPoints1 = document.getElementById('numberOfPoints1');
const numberOfPoints2 = document.getElementById('numberOfPoints2');
const buttonClose1 = document.getElementById('buttonClose1');
const buttonClose2 = document.getElementById('buttonClose2');
const hideCode = document.getElementById('hideCode');
const winnerPoints1 = document.getElementById('winnerPoints1');
const loserPoints1 = document.getElementById('loserPoints1');
const winnerPoints2 = document.getElementById('winnerPoints2');
const loserPoints2 = document.getElementById('loserPoints2');

// Обработчики событий нажатий на кнопки в меню
newGameBtn.addEventListener('click', newGame);
newGameBtn.addEventListener('click', music);
joinGameBtn.addEventListener('click', joinGame);
joinGameBtn.addEventListener('click', music);

buttonClose1.addEventListener('click', reset);
buttonClose2.addEventListener('click', reset);

// В случае нажатия кнопки новая игра мы отправляем на сервер событие новая игра и инициализируем компоненты
function newGame() {
  socket.emit('newGame');
  init();
}

// В случае нажатия кнопки присоединиться к игре мы отправляем на сервер событие присоединиться к игре и код игры
// а также инициализируем компоненты
function joinGame() {
  const code = gameCodeInput.value;
  socket.emit('joinGame', code);
  init();
}

let canvas, ctx;
let playerNumber;
let gameActive = false;
let points1 = 0;
let points2 = 0;

// Запуск фоновой музыки
function music() {
  var audio = new Audio('images/mainsound.mp3');
  audio.volume = 0.02;
  audio.play();
}

let timer;

// Инициализация компонентов
function init() {
  timer = true;
  // Скрываем меню
  initialScreen.style.display = "none";
  gameScreen.style.display = "block";

  canvas = document.getElementById('canvas');
  ctx = canvas.getContext('2d');

  canvas.width = 1200;
  canvas.height = 600;

  // Добавляем заливку в виде изображения
  const ground = ctx.createPattern(document.getElementById("ground"), "repeat");
  ctx.fillStyle = ground;

  // Отрисовка игрового поля 1200x600
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  document.addEventListener('keydown', keydown);
  gameActive = true;
}

// Отправка события нажатия клавиши на сервер
function keydown(e) {
  socket.emit('keydown', e.keyCode);
}

// Отрисовка игры
function paintGame(state) {
  const ground = ctx.createPattern(document.getElementById("ground"), "repeat");
  ctx.fillStyle = ground;

  ctx.fillRect(0, 0, canvas.width, canvas.height);

  const food = state.food;
  const gridsize = state.gridsize;
  const size = canvas.width / gridsize;

  // Отрисовка еды
  const apple = ctx.createPattern(document.getElementById("apple"), "repeat");
  ctx.fillStyle = apple;
  ctx.fillRect(food.x * size, food.y * size, size, size);


  paintPlayer(state.players, size);
}

// Отрисовка змейки
function paintPlayer(playerState, size) {
  let snake1 = playerState[0].snake;
  let snake2 = playerState[1].snake;
  let head1 = snake1.pop();
  let head2 = snake2.pop();

  const hup = ctx.createPattern(document.getElementById("hup"), "repeat");
  const hdown = ctx.createPattern(document.getElementById("hdown"), "repeat");
  const hleft = ctx.createPattern(document.getElementById("hleft"), "repeat");
  const hright = ctx.createPattern(document.getElementById("hright"), "repeat");
  const hup2 = ctx.createPattern(document.getElementById("hup2"), "repeat");
  const hdown2 = ctx.createPattern(document.getElementById("hdown2"), "repeat");
  const hleft2 = ctx.createPattern(document.getElementById("hleft2"), "repeat");
  const hright2 = ctx.createPattern(document.getElementById("hright2"), "repeat");

  if (playerState[0].vel.x === 1) {
    ctx.fillStyle = hright;
    ctx.fillRect(head1.x * size, head1.y * size, size, size);
  }
  else if (playerState[0].vel.x === -1) {
    ctx.fillStyle = hleft;
    ctx.fillRect(head1.x * size, head1.y * size, size, size);
  }
  else if (playerState[0].vel.y === -1) {
    ctx.fillStyle = hup;
    ctx.fillRect(head1.x * size, head1.y * size, size, size);
  }
  else if (playerState[0].vel.y === 1) {
    ctx.fillStyle = hdown;
    ctx.fillRect(head1.x * size, head1.y * size, size, size);
  }

  if (playerState[1].vel.x === 1) {
    ctx.fillStyle = hright2;
    ctx.fillRect(head2.x * size, head2.y * size, size, size);
  }
  else if (playerState[1].vel.x === -1) {
    ctx.fillStyle = hleft2;
    ctx.fillRect(head2.x * size, head2.y * size, size, size);
  }
  else if (playerState[1].vel.y === -1) {
    ctx.fillStyle = hup2;
    ctx.fillRect(head2.x * size, head2.y * size, size, size);
  }
  else if (playerState[1].vel.y === 1) {
    ctx.fillStyle = hdown2;
    ctx.fillRect(head2.x * size, head2.y * size, size, size);
  }

  ctx.fillStyle = SNAKE_COLOUR;

  for (let cell of snake1) {
    ctx.fillRect(cell.x * size, cell.y * size, size, size);
  }

  ctx.fillStyle = SNAKE_COLOUR2;

  for (let cell of snake2) {
    ctx.fillRect(cell.x * size, cell.y * size, size, size);
  }

}

// Запоминаем номер игрока, полученный от сервера
function handleInit(number) {
  playerNumber = number;
}

// Обработка события о текущем положение дел в игре
function handleGameState(gameState) {

  if (!gameActive) {
    return;
  }
  else {
    // Скрываем у всех текст кода для входа второго игрока
    hideCode.style.display = "none";
  }

  // Запускаем таймер один раз
  if (timer) {
    startTimer();
    timer = false;
  }

  gameState = JSON.parse(gameState);
  requestAnimationFrame(() => paintGame(gameState));
}

// Обработка события окончания игры
function handleGameOver(data) {

  if (!gameActive) {
    return;
  }

  pauseTimer();

  data = JSON.parse(data);

  gameActive = false;

  // Показ модального окна победителя/проигравшего и число набранных очков
  if (data.winner === playerNumber) {
    window.open("#openModal1", "_self");
    winnerPoints1.innerText = points1;
    loserPoints1.innerText = points2;
  }
  else {
    window.open("#openModal2", "_self");
    winnerPoints2.innerText = points1;
    loserPoints2.innerText = points2;
  }

}

// Функция отображения кода игры пользователю
function handleGameCode(gameCode) {
  gameCodeDisplay.innerText = gameCode;
}

// Функция оповещения подключающегося игрока о несуществующей комнате
function handleUnknownCode() {
  reset();
  alert('Unknown Game Code')
}

// Функция оповещения подключающегося игрока о невозможности подключиться к игре, 
// так как в ней уже максимальное кол-во игроков
function handleTooManyPlayers() {
  reset();
  alert('This game is already in progress');
}

// Функция сброса 
function reset() {
  playerNumber = null;
  gameCodeInput.value = '';
  initialScreen.style.display = "block";
  gameScreen.style.display = "none";

  window.open('game.html', "_self");
}

// Получить очки 1 игрока и выполнить звук поедания
function getPlayer1Points(points) {

  if (points1 != points) {
    var audio = new Audio('images/Hrust.mp3');
    audio.play();
  }

  points1 = points;
  numberOfPoints1.innerText = points;
}

// Получить очки 2 игрока и выполнить звук поедания
function getPlayer2Points(points) {

  if (points2 != points) {
    var audio = new Audio('images/Hrust.mp3');
    audio.play();
  }

  points2 = points;
  numberOfPoints2.innerText = points;
}

// Начало блока кода с таймером
function timeToString(time) {
  let diffInHrs = time / 3600000;
  let hh = Math.floor(diffInHrs);

  let diffInMin = (diffInHrs - hh) * 60;
  let mm = Math.floor(diffInMin);

  let diffInSec = (diffInMin - mm) * 60;
  let ss = Math.floor(diffInSec);

  let diffInMs = (diffInSec - ss) * 100;
  let ms = Math.floor(diffInMs);

  let formattedMM = mm.toString().padStart(2, "0");
  let formattedSS = ss.toString().padStart(2, "0");
  let formattedMS = ms.toString().padStart(2, "0");

  return `${formattedMM}:${formattedSS}:${formattedMS}`;
}

let startTime;
let elapsedTime = 0;
let timerInterval;

// Показ таймера на странице
function print(txt) {
  document.getElementById("display").innerHTML = txt;
}

// Запуск таймера
function startTimer() {

  if (gameScreen.style.display === "block") {
    startTime = Date.now() - elapsedTime;
    timerInterval = setInterval(function printTime() {
      elapsedTime = Date.now() - startTime;
      print(timeToString(elapsedTime));
    }, 10);
  }

}

// Пауза таймера при окончании игры
function pauseTimer() {
  clearInterval(timerInterval);
}